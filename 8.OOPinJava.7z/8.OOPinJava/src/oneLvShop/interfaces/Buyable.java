package oneLvShop.interfaces;

import java.math.BigDecimal;

public interface Buyable {

    public BigDecimal getPrice();
}
