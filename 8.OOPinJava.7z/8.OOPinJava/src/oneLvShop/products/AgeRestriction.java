package oneLvShop.products;

public enum AgeRestriction {
    None, Teenager, Adult
}