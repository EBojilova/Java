package shapes.interfaces;

public interface AreaMeasurable {

    public double getArea();
}
